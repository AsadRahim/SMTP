-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 23, 2019 at 11:28 AM
-- Server version: 5.7.25-0ubuntu0.18.04.2
-- PHP Version: 7.2.15-0ubuntu0.18.04.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smtpserver`
--

-- --------------------------------------------------------

--
-- Table structure for table `INBOX`
--

CREATE TABLE `INBOX` (
  `ID` int(11) NOT NULL,
  `FROMM` varchar(255) NOT NULL,
  `INBOXOF` varchar(255) NOT NULL,
  `TOO` varchar(255) NOT NULL,
  `CREATED` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `SUBJECT` varchar(255) NOT NULL,
  `BODY` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `INBOX`
--

INSERT INTO `INBOX` (`ID`, `FROMM`, `INBOXOF`, `TOO`, `CREATED`, `SUBJECT`, `BODY`) VALUES
(5, 'sibghat@mail.com', 'mail@asad.com', 'mail@asad.com', '2019-04-23 08:13:22', 'i\'m here', 'main hun na'),
(7, 'mail@asad.com', 'sibghat@mail.com', 'sibghat@mail.com', '2019-04-23 08:19:08', 'okay okay', 'ye lo email'),
(8, 'mail@asad.com', 'sibghat@mail.com', 'sibghat@mail.com', '2019-04-23 10:44:34', 'This This is my life', 'kiska hai ye tumko intzar main hun na'),
(9, 'mail@asad.com', 'gmail@asad.com', 'gmail@asad.com', '2019-04-23 10:50:51', 'testMail', 'ye to pyara bacha hai \n\r.\n\r');

-- --------------------------------------------------------

--
-- Table structure for table `OUTBOX`
--

CREATE TABLE `OUTBOX` (
  `ID` int(11) NOT NULL,
  `FROMM` varchar(255) NOT NULL,
  `TOO` varchar(255) NOT NULL,
  `CREATED` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `SUBJECT` varchar(255) NOT NULL,
  `BODY` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `OUTBOX`
--

INSERT INTO `OUTBOX` (`ID`, `FROMM`, `TOO`, `CREATED`, `SUBJECT`, `BODY`) VALUES
(1, 'gmail@asad.com', 'mail@asad.com', '2019-04-22 21:00:13', 'you Email is this', 'i\'m very busy person right now'),
(2, 'mail@asad.com', 'sibghat@mail.com', '2019-04-23 04:27:28', 'Unique', 'hai apna dil to awara '),
(3, 'mail@asad.com', 'sibghat@mail.com', '2019-04-23 08:15:38', 'uniqu hai', 'main hun na dekh lo idhar to'),
(4, 'mail@asad.com', 'sibghat@mail.com', '2019-04-23 08:19:08', 'okay okay', 'ye lo email'),
(5, 'mail@asad.com', 'sibghat@mail.com', '2019-04-23 10:44:34', 'This This is my life', 'kiska hai ye tumko intzar main hun na'),
(6, 'mail@asad.com', 'gmail@asad.com', '2019-04-23 10:50:51', 'testMail', 'ye to pyara bacha hai \n\r.\n\r');

-- --------------------------------------------------------

--
-- Table structure for table `USERS`
--

CREATE TABLE `USERS` (
  `username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `USERS`
--

INSERT INTO `USERS` (`username`, `Password`, `name`, `created`) VALUES
('gmail@asad.com', '12345678', 'sibghat', '2019-04-22 20:58:21'),
('hubbah@gmi[C[C[C[C[C[Cmail.com', '12345', 'paHnubbah', '2019-04-23 11:25:34'),
('mail@asad.com', 'asad123', 'asad', '2019-04-18 02:11:01'),
('sibghat@mail.com', '123456', 'sibghatullah', '2019-04-22 23:46:14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `INBOX`
--
ALTER TABLE `INBOX`
  ADD UNIQUE KEY `ID` (`ID`),
  ADD KEY `INBOXOF` (`INBOXOF`);

--
-- Indexes for table `OUTBOX`
--
ALTER TABLE `OUTBOX`
  ADD UNIQUE KEY `ID` (`ID`),
  ADD KEY `FROMM` (`FROMM`);

--
-- Indexes for table `USERS`
--
ALTER TABLE `USERS`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `INBOX`
--
ALTER TABLE `INBOX`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `OUTBOX`
--
ALTER TABLE `OUTBOX`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `INBOX`
--
ALTER TABLE `INBOX`
  ADD CONSTRAINT `INBOX_ibfk_1` FOREIGN KEY (`INBOXOF`) REFERENCES `USERS` (`username`);

--
-- Constraints for table `OUTBOX`
--
ALTER TABLE `OUTBOX`
  ADD CONSTRAINT `OUTBOX_ibfk_1` FOREIGN KEY (`FROMM`) REFERENCES `USERS` (`username`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
