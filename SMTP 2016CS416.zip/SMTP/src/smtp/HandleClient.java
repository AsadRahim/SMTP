/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smtp;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author asad
 */
public class HandleClient implements Runnable {

    Properties serverProp = new Properties();
    private final Socket clientServer;
    BufferedReader inn;
    PrintWriter outt;
    Connection con;
    Statement st;
    ResultSet res;
    String uname, mailFrom, mailTo, subj;

    public HandleClient(Socket client) {
        clientServer = client;
    }

    @Override
    public void run() {
        try {
            //System.out.println("smtp.HandleClient.run() is runing");
            InputStream in = clientServer.getInputStream();
            OutputStream out = clientServer.getOutputStream();
            inn = new BufferedReader(new InputStreamReader(in));
            outt = new PrintWriter(new OutputStreamWriter(out));
            boolean act = true;
            if (inn.readLine().equalsIgnoreCase("EHLO")) {
                outt.write("250\n\r EHLO This is Mail@Asad.com & FOR HELP use \'?\'\n\r");
                outt.flush();
                int i = 0;
                while (true) {
                    String lev = inn.readLine();
                    if (lev.equalsIgnoreCase("AUTH")) {
                        outt.write("250\n\rOk username: ");
                        outt.flush();
                        try {
                            if (authenticate()) {
                                outt.write("250\n\rBe sure Commands should be in capital case: for help use this '?'\n\r");
                                outt.flush();
                                while (act == true) {
                                    switch (inn.readLine()) {
                                        case "LIST":
                                            String list = ListAction();
                                            if (list.equals("")) {
                                                outt.write("454\n\rEMPTY");
                                                outt.flush();
                                            } else {
                                                outt.write("250\n\r" + list);
                                                outt.flush();
                                            }
                                            break;
                                        case "DELETE":
                                            outt.write("250\n\rEmail Number: ");
                                            outt.flush();
                                            if (!DeleAction(Integer.parseInt(inn.readLine()))) {
                                                outt.write("454\n\r");
                                                outt.flush();
                                            }
                                            break;
                                        case "LISTU":
                                            String list1 = ListActionU();
                                            if (list1.equals("")) {
                                                outt.write("454\n\rEMPTY");
                                                outt.flush();
                                            } else {
                                                outt.write("250\n\r" + list1);
                                                outt.flush();
                                            }
                                            break;
                                        case "DELETEU":
                                            outt.write("250\n\rEmail Number: ");
                                            outt.flush();
                                            if (!DeleActionU(Integer.parseInt(inn.readLine()))) {
                                                outt.write("454\n\r");
                                                outt.flush();
                                            }
                                            break;
                                        case "STAT":
                                            int lnt = staAction();
                                            if (-1 == lnt) {
                                                outt.write(0);
                                                outt.flush();
                                            } else {
                                                outt.write(Integer.toString(lnt) + "\n\r");
                                                outt.flush();
                                            }
                                            break;
                                        case "RETR":
                                            outt.write("250\n\rPermission Granted\n\r");
                                            outt.flush();
                                            String mail = retrAction(Integer.parseInt(inn.readLine()));
                                            if ("".equals(mail)) {
                                                outt.write("454\n\r");
                                                outt.flush();
                                            } else {
                                                outt.write(mail);
                                                outt.flush();
                                            }
                                            break;
                                        case "RETRU":
                                            outt.write("250\n\rPermission Granted\n\r");
                                            outt.flush();
                                            String mail1 = retrActionU(Integer.parseInt(inn.readLine()));
                                            if ("".equals(mail1)) {
                                                outt.write("454\n\r");
                                                outt.flush();
                                            } else {
                                                outt.write(mail1);
                                                outt.flush();
                                            }
                                            break;
                                        case "LOGOFF":
                                            LogOffAction();
                                            act = false;
                                            break;
                                        case "MAIL FROM":
                                            mFrom();
                                            break;
                                        case "RCPT TO":
                                            mTo();
                                            break;
                                        case "DATA":
                                            DataSend();
                                            break;
                                        case "QUIT":
                                            quitAction();
                                            break;
                                        case "?":
                                            outt.write("LIST    return list of emails\n\r" + "DELETE     del email by ID\n\r" + "LISTU    return list of emails outbox\n\r" + "DELETEU     del email by ID in OUTBOX\n\r" + "STAT    total numbers of emails\n\r" + "RETR     return selected email\n\r" + "RETRU     return selected email from outbox\n\r" + "LOGOFF     close the client server communication\n\r" + "MAIl FROM      ADDRESS\n\r" + "RCPT TO        ADDRESS\n\r" + "DATA       email body type in it\n\r" + "QUIT       destroy connection\n\r");
                                            outt.flush();
                                            break;
                                    }
                                }
                            } else {
                                outt.write("454\n\r");
                                outt.flush();
                            }
                        } catch (SQLException ex) {
                            Error err = new Error("ERROR Try Catch", ex.getLocalizedMessage());
                            err.dispose();
                            err.setVisible(true);
                        }
                        i++;
                    } else if (lev.equalsIgnoreCase("createUser")) {
                        if (!createUser()) {
                            outt.write("454\n\r");
                            outt.flush();
                        } else {
                            outt.write("250\n\r");
                            outt.flush();
                        }

                    } else if (lev.equals("?")) {
                        outt.write("CREATEUSER      THIS COMMAND ONLY FOR NEW USER\n\r" + "AUTH       COMMAND FOR USER & PASSWORD AUTHENTICATION\n\r");
                        outt.flush();
                    }
                    if (i == 4) {
                        this.clientServer.close();
                        return;
                    }
                }
            }

        } catch (IOException io) {
            Error err = new Error("ERROR Try Catch", io.getLocalizedMessage());
            err.dispose();
            err.setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(HandleClient.class.getName()).log(Level.SEVERE, null, ex);
        }
        //
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     *
     * @throws SQLException
     * @throws IOException
     */
    private void DataSend() throws SQLException, IOException {
        outt.write("FROM: " + mailFrom + "\n\r" + "TO: " + mailTo + "\n\r" + "Subject: " + subj + "\n\r" + "354\n\r");
        outt.flush();
        String body = new String();
        String cru = "";
        while (!cru.equals(".")) {
            cru = inn.readLine();
            body += cru + "\n\r";
        }

        if (createDBcon()) {
            outt.write("250\n\r");
            outt.flush();
            st = con.createStatement();
            int affected_row = st.executeUpdate("INSERT INTO INBOX(FROMM,INBOXOF,TOO,SUBJECT,BODY) VALUES(\'" + mailFrom + "\',\'" + mailTo + "\',\'" + mailTo + "\',\'" + subj + "\',\'" + body + "\'" + ")");
            affected_row = st.executeUpdate("INSERT INTO OUTBOX(FROMM,TOO,SUBJECT,BODY) VALUES(\'" + mailFrom + "\',\'" + mailTo + "\',\'" + subj + "\',\'" + body + "\'" + ")");
        }
        closeDbcon();
    }

    /**
     *
     * @return @throws IOException
     * @throws SQLException
     */
    private boolean authenticate() throws IOException, SQLException {

        if (createDBcon()) {
            //prepare to execute
            st = con.createStatement();
            //execute query and get result set to read
            //get all the data from result set
            String uss = inn.readLine();
            uname = uss;
            String qry = "SELECT * FROM USERS WHERE username=" + "\'" + uss + "\'";
            System.out.println(uss);
            res = st.executeQuery(qry);
            if (res.next()) {
                outt.write("250\n\r pass: ");
                outt.flush();
                uss = inn.readLine();
                if (res.getString("Password").equals(uss)) {
                    outt.write("250\n\r");
                    outt.flush();
                    closeDbcon();
                    return true;
                } else {
                    outt.write("454\n\r");
                    outt.flush();
                    closeDbcon();
                }
            } else {
                outt.write("454\n\r");
                outt.flush();
                closeDbcon();
            }
        }
        closeDbcon();
        return false;
    }

    /**
     *
     * @return @throws IOException
     * @throws SQLException
     */
    private String ListAction() throws IOException, SQLException {
        if (createDBcon()) {
            //outt.write("250\n\r");
            //outt.flush();
            st = con.createStatement();
            String qry = "SELECT * FROM INBOX WHERE INBOXOF =\'" + uname + "\'";
            res = st.executeQuery(qry);
            int id;
            String from, subject, total = "";
            while (res.next()) {
                id = res.getInt("ID");
                from = res.getString("FROMM");
                //to = res.getString("TOO");
                //created = res.getString("CREATED");
                subject = res.getString("SUBJECT");
                //body = res.getString("BODY");
                total += id + "\n\r SUBJECT: " + subject + "\n\r FROM: " + from + "\n\r";
            }
            closeDbcon();
            return total;
        } else {
            outt.write("454\n\r");
            outt.flush();
            closeDbcon();
            return "";
        }
    }

    ;
    /**
     * 
     * @return
     * @throws IOException
     * @throws SQLException 
     */
    private String ListActionU() throws IOException, SQLException {
        if (createDBcon()) {
            //outt.write("250\n\r");
            //outt.flush();
            st = con.createStatement();
            String qry = "SELECT * FROM OUTBOX WHERE FROMM =\'" + uname + "\'";
            res = st.executeQuery(qry);
            int id;
            String from, subject, total = "";
            while (res.next()) {
                id = res.getInt("ID");
                from = res.getString("FROMM");
                //to = res.getString("TOO");
                //created = res.getString("CREATED");
                subject = res.getString("SUBJECT");
                //body = res.getString("BODY");
                total += id + "\n\r SUBJECT: " + subject + "\n\r FROM: " + from + "\n\r";
            }
            closeDbcon();
            return total;
        } else {
            outt.write("454\n\r");
            outt.flush();
            closeDbcon();
            return "";
        }
    }

    ;
    /**
     * 
     * @throws SQLException
     * @throws IOException 
     */
    private void mFrom() throws SQLException, IOException {
        outt.write("MAIL FROM: ");
        outt.flush();
        if (createDBcon()) {
            st = con.createStatement();
            String uss = inn.readLine();
            if (uss.equals(uname)) {
                res = st.executeQuery("SELECT * FROM USERS WHERE username=\'" + uss + "\'");
                while (res.next()) {
                    mailFrom = res.getString("username");
                    outt.write("250\n\r");
                    outt.flush();
                }
            } else {
                outt.write("454\n\r");
                outt.flush();
            }
        }
        closeDbcon();
    }

    /**
     *
     * @throws SQLException
     * @throws IOException
     */
    private void mTo() throws SQLException, IOException {
        outt.write("MAIL TO: ");
        outt.flush();
        if (createDBcon()) {
            st = con.createStatement();
            res = st.executeQuery("SELECT * FROM USERS WHERE username=\'" + inn.readLine() + "\'");
            while (res.next()) {
                mailTo = res.getString("username");
                outt.write("250\n\r");
                outt.flush();
            }
            outt.write("SUBJECT: ");
            outt.flush();
            subj = inn.readLine();
            outt.write("250\n\r");
            outt.flush();
        }
        closeDbcon();
    }

    /**
     *
     * @throws IOException
     */
    private void LogOffAction() throws IOException {
        outt.write("Connection Is Terminated\n\r");
        outt.flush();
        this.clientServer.close();
    }

    /**
     *
     * @throws IOException
     */
    private void quitAction() throws IOException {
        outt.write("221 SERVICE IS CLOSING\n\r");
        outt.flush();
        this.clientServer.close();
    }

    /**
     *
     * @param i
     * @return
     * @throws SQLException
     * @throws IOException
     */
    private boolean DeleAction(int i) throws SQLException, IOException {
        if (createDBcon()) {
            st = con.createStatement();
            int affected_rows = st.executeUpdate("DELETE FROM INBOX WHERE ID=" + i);
            if (affected_rows == 1) {
                outt.write("250\n\r");
                outt.flush();
                closeDbcon();
                return true;
            }
        }
        return false;
    }

    ;
    /**
     * 
     * @param i
     * @return
     * @throws SQLException
     * @throws IOException 
     */
    private boolean DeleActionU(int i) throws SQLException, IOException {
        if (createDBcon()) {
            st = con.createStatement();
            int affected_rows = st.executeUpdate("DELETE FROM OUTBOX WHERE ID=" + i);
            if (affected_rows == 1) {
                outt.write("250\n\r");
                outt.flush();
                closeDbcon();
                return true;
            }
        }
        return false;
    }

    ;
    /**
     * 
     * @return
     * @throws SQLException
     * @throws IOException 
     */
    private int staAction() throws SQLException, IOException {
        if (createDBcon()) {
            st = con.createStatement();
            res = st.executeQuery("SELECT * FROM INBOX WHERE INBOXOF=\'" + uname + "\'");
            int i = 0;
            while (res.next()) {
                i++;
            }
            closeDbcon();
            return i;
        }
        return -1;
    }

    ;
    /**
     * 
     * @return
     * @throws SQLException
     * @throws IOException 
     */
    private boolean createUser() throws SQLException, IOException {
        String uuname, name, pas;
        uuname ="";
        name="";
        pas="";
        if (createDBcon()) {
            st = con.createStatement();
            outt.write("NEW username: ");
            outt.flush();
            uuname +=inn.readLine();
            outt.write("NEW password: ");
            outt.flush();
            pas += inn.readLine();
            outt.write("NEW name: ");
            outt.flush();
            name += inn.readLine();
            int infacted_rows = st.executeUpdate("INSERT INTO USERS (username,Password,name) VALUES (" + "\'" + uuname + "\'" + "," + "\'" + pas + "\'" + "," + "\'" + name + "\'" + ")", Statement.RETURN_GENERATED_KEYS);
            return infacted_rows == 1;
        }
        return false;
    }

    ;
    /**
     * 
     * @param i
     * @return
     * @throws SQLException
     * @throws IOException 
     */
    private String retrAction(int i) throws SQLException, IOException {
        String from, to, created, subject, body, total = "";
        if (createDBcon()) {
            st = con.createStatement();
            res = st.executeQuery("SELECT * FROM INBOX WHERE ID =" + i);
            int id;
            while (res.next()) {
                id = res.getInt("ID");
                from = res.getString("FROMM");
                to = res.getString("TOO");
                created = res.getString("CREATED");
                subject = res.getString("SUBJECT");
                body = res.getString("BODY");
                total = MessageFormat.format("ID: {0}\n\r FROM: {1}\n\r TO: {2}\n\r TIME DATE: {3}\n\r SUBJECT: {4}\n\r BODY:{5}.\n\r", id, from, to, created, subject, body);
            }
            closeDbcon();
            return total;
        }
        return "";
    }

    /**
     *
     * @param i
     * @return
     * @throws SQLException
     * @throws IOException
     */
    private String retrActionU(int i) throws SQLException, IOException {
        String from, to, created, subject, body, total = "";
        if (createDBcon()) {
            st = con.createStatement();
            res = st.executeQuery("SELECT * FROM OUTBOX WHERE ID =" + i);
            int id;
            while (res.next()) {
                id = res.getInt("ID");
                from = res.getString("FROMM");
                to = res.getString("TOO");
                created = res.getString("CREATED");
                subject = res.getString("SUBJECT");
                body = res.getString("BODY");
                total = MessageFormat.format("ID: {0}\n\r FROM: {1}\n\r TO: {2}\n\r TIME DATE: {3}\n\r SUBJECT: {4}\n\r BODY:{5}.\n\r", id, from, to, created, subject, body);
            }
            closeDbcon();
            return total;
        }
        return "";
    }

    ;
/**
 * 
 * @return
 * @throws SQLException
 * @throws IOException 
 */
    private boolean createDBcon() throws SQLException, IOException {
        File config;
        config = new File("config.txt");
        serverProp.load(new FileInputStream(config));
        //load driver
        //create connection
        con = DriverManager.getConnection(
                "jdbc:mysql://" + serverProp.getProperty("dbhost") + ":" + serverProp.getProperty("port") + "/" + serverProp.getProperty("dbname")
                + "?" + "user=" + serverProp.getProperty("dbuser") + "&password=" + serverProp.getProperty("dbpwd"));
        //connection success
        return true;
    }

    ;
/**
 * 
 * @throws SQLException 
 */
    private void closeDbcon() throws SQLException {

        con.close();

    }
;

}
